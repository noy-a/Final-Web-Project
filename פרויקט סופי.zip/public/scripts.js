// scripts.js

// HOME PAGE

// Reviews carousel
document.addEventListener("DOMContentLoaded", function() {
    // --- 1. Infinite carousel logic ---
    const progGrid = document.getElementById('productsGrid');
    const nextProgBtn = document.getElementById('nextProg');
    const prevProgBtn = document.getElementById('prevProg');

    if (nextProgBtn && progGrid) {
        // Move first child to end when clicking next
        nextProgBtn.addEventListener('click', () => {
            progGrid.appendChild(progGrid.firstElementChild);
        });
    }

    if (prevProgBtn && progGrid) {
        // Move last child to start when clicking previous
        prevProgBtn.addEventListener('click', () => {
            progGrid.prepend(progGrid.lastElementChild);
        });
    }

    // --- 2. Testimonials logic ---
    const testimonials = [
        { text: "התלמידים חזרו מהסדנה עם מוטיבציה גבוהה, ביטחון עצמי וחשיבה יזמית מפותחת.", rating: 5 },
        { text: "תוכנית חינוכית מעשירה שמשלבת חינוך פיננסי עם כלים מעשיים מעולם היזמות.", rating: 4 },
        { text: "ראינו שינוי אמיתי בגישה של התלמידים לאחריות אישית וניהול כסף.", rating: 5 },
        { text: "יום ההאקתון היה חוויה לימודית יוצאת דופן ששילבה יצירתיות ועבודת צוות.", rating: 4 },
        { text: "FutureWize מחברת בין עולם הסטארטאפים לבין הכיתה בצורה נגישה ומעוררת השראה.", rating: 5 },
        { text: "הצוות מקצועי, נעים ומעורר השראה – התלמידים היו מעורבים לאורך כל הדרך.", rating: 5 }
    ];

    let startIndex = 0;
    const testGrid = document.getElementById("testimonialsGrid");

    function renderTestimonials() {
        if (!testGrid) return; 
        testGrid.innerHTML = "";
        for (let i = 0; i < 3; i++) {
            const index = (startIndex + i) % testimonials.length;
            const t = testimonials[index];
            const card = document.createElement("div");
            card.className = "testimonial-card";
            const fullStars = "★".repeat(t.rating);
            const emptyStars = "☆".repeat(5 - t.rating);
            // Insert testimonial text and star rating
            card.innerHTML = `
                <p>"${t.text}"</p>
                <div class="stars" style="color: #f1c40f; font-size: 22px;">${fullStars}${emptyStars}</div>
            `;
            testGrid.appendChild(card);
        }
    }

    const nextTestBtn = document.getElementById("nextBtn");
    const prevTestBtn = document.getElementById("prevBtn");

    // Navigation for testimonials carousel
    if (nextTestBtn) nextTestBtn.addEventListener("click", () => { startIndex = (startIndex + 1) % testimonials.length; renderTestimonials(); });
    if (prevTestBtn) prevTestBtn.addEventListener("click", () => { startIndex = (startIndex - 1 + testimonials.length) % testimonials.length; renderTestimonials(); });

    renderTestimonials();
});

// LOG IN WELCOME (runs on all pages)
document.addEventListener("DOMContentLoaded", () => {
  const username = localStorage.getItem("username");

  const welcome = document.getElementById("welcomeUser");
  const authSep = document.getElementById("authSep");
  const logoutBtn = document.getElementById("logoutBtn");
  const profileBtn = document.getElementById("profileBtn"); // "Personal area"

  if (username) {
    // Show username with wave emoji
    if (welcome) {
      welcome.innerHTML = `שלום ${username} <span class="wave-emoji">👋</span>`;
      welcome.style.display = "inline";
    }

    // Show separator and logout
    if (authSep) authSep.style.display = "inline";
    if (logoutBtn) logoutBtn.style.display = "inline";

    // Hide "Personal area" when user is logged in
    if (profileBtn) profileBtn.style.display = "none";
  } else {
    // User not logged in
    if (welcome) welcome.style.display = "none";
    if (authSep) authSep.style.display = "none";
    if (logoutBtn) logoutBtn.style.display = "none";

    // Show "Personal area"
    if (profileBtn) profileBtn.style.display = "inline-flex";
  }
});

// LOG OUT function
function logout() {
  localStorage.removeItem("username");
  localStorage.removeItem("userEmail");
  window.location.href = "index.html";
}

// LOGIN FORM VALIDATION (only on login page)
const loginForm = document.getElementById("loginForm");

if (loginForm) {
  loginForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const email = document.getElementById("email");
    const password = document.getElementById("password");

    // Reset previous validation messages
    email.setCustomValidity("");
    password.setCustomValidity("");

    // Check for basic email format
    if (!email.value.includes("@")) {
      email.setCustomValidity("אנא הזן אימייל תקין");
      email.reportValidity();
      return;
    }

    // Check password length
    if (password.value.length < 4) {
      password.setCustomValidity("סיסמה קצרה מדי");
      password.reportValidity();
      return;
    }

    // Submit form to server
    event.target.submit();
  });
}

// PRODUCTS PAGE
document.addEventListener("DOMContentLoaded", function() {
    
    const productCards = document.querySelectorAll(".product-card");

    productCards.forEach(card => {
        const cardContent = card.querySelector(".card-content");
        const originalHTML = cardContent.innerHTML;
        const infoHTML = (cardContent.dataset.info || "").replaceAll("\n", "<br>");
        const programName = cardContent.dataset.name || "תוכנית";
        let isExpanded = false;

        cardContent.addEventListener("click", function(e) {
            if (!e.target.classList.contains("more-info-btn")) return;
            e.preventDefault();

            if (!isExpanded) {
                // Expand card content
                cardContent.innerHTML = `
                    <div class="info-scroll">
                        <p style="text-align:right;">${infoHTML}</p>
                    </div>
                    <div class="card-actions" style="margin-top:10px; display:flex; gap:10px; justify-content:center;">
                        <button class="more-info-btn" type="button">חזרה</button>
                        <button class="add-to-cart-btn" type="button" data-name="${programName}">הוסף לעגלה</button>
                    </div>
                `;

                // Attach click event to "Add to cart" button
                const addBtn = cardContent.querySelector(".add-to-cart-btn");
                addBtn.addEventListener("click", (ev) => {
                    ev.stopPropagation(); // Prevent card from collapsing
                    addToCart(programName);
                });

                isExpanded = true;

            } else {
                // Collapse card
                cardContent.innerHTML = originalHTML;
                isExpanded = false;
            }
        });

    });

    // Function to add product to cart
    function addToCart(name) {
        const cart = JSON.parse(localStorage.getItem("cart")) || [];
        cart.push(name);
        localStorage.setItem("cart", JSON.stringify(cart));
        alert(`התוכנית "${name}" נוספה לעגלה בהצלחה!`);
    }

    // --- Filters logic ---
    const filterButtons = document.querySelectorAll(".filter-btn");
    filterButtons.forEach(btn => {
        btn.addEventListener("click", () => {
            // Remove active class from all buttons
            filterButtons.forEach(b => b.classList.remove("active"));
            btn.classList.add("active");

            const filter = btn.dataset.filter;
            productCards.forEach(card => {
                // Show/hide based on selected category
                if (filter === "all" || card.dataset.category === filter) {
                    card.style.display = "flex";
                } else {
                    card.style.display = "none";
                }
            });
        });
    });

});

// GALLERY PAGE
document.addEventListener("DOMContentLoaded", () => {
    const imagePaths = [
        "images/image1.jpeg",
        "images/image2.jpeg",
        "images/image3.jpeg",
        "images/image4.jpeg",
        "images/image5.jpeg",
        "images/image6.jpeg"
    ];

    const carousel = document.querySelector(".carousel");
    const prevBtn = document.querySelector(".carousel-btn.prev");
    const nextBtn = document.querySelector(".carousel-btn.next");

    let currentIndex = 0;

    // Function to create image element
    function createImage(src, alt) {
        const img = document.createElement("img");
        img.src = src;
        img.alt = alt;
        img.classList.add("carousel-img");
        return img;
    }

    // Load all images into carousel
    imagePaths.forEach((path, i) => {
        const img = createImage(path, `תמונה ${i + 1}`);
        if (i === 0) img.classList.add("active"); // First image active
        carousel.appendChild(img);
    });

    const slides = carousel.querySelectorAll("img");

    // Show slide by index
    function showSlide(index) {
        slides.forEach(img => img.classList.remove("active"));
        slides[index].classList.add("active");
    }

    // Navigation buttons
    prevBtn.addEventListener("click", () => {
        currentIndex = (currentIndex - 1 + slides.length) % slides.length;
        showSlide(currentIndex);
    });

    nextBtn.addEventListener("click", () => {
        currentIndex = (currentIndex + 1) % slides.length;
        showSlide(currentIndex);
    });
});

// --- CONTACT PAGE ---
document.addEventListener("DOMContentLoaded", () => {
    const contactForm = document.getElementById("contactForm");

    if (!contactForm) return; 

    const fileInput = document.getElementById("file-upload");
    const fileNameDisplay = document.getElementById("file-name-display");
    const fileStatusContainer = document.getElementById("file-status-container");
    const messageInput = document.getElementById("message");
    const charCounter = document.getElementById("charCounter");

    // File input handling
    if (fileInput) {
        fileInput.addEventListener("change", function() {
            if (this.files && this.files.length > 0) {
                if (fileNameDisplay) fileNameDisplay.textContent = this.files[0].name;
                if (fileStatusContainer) fileStatusContainer.style.display = "flex";
            }
        });

        // Remove file button
        const removeFileBtn = document.getElementById("remove-file-btn");
        if (removeFileBtn) {
            removeFileBtn.addEventListener("click", function() {
                fileInput.value = "";
                if (fileStatusContainer) fileStatusContainer.style.display = "none";
                if (fileNameDisplay) fileNameDisplay.textContent = "";
            });
        }
    }

    // Character counter for message
    if (messageInput && charCounter) {
        messageInput.addEventListener("input", () => {
            const currentLength = messageInput.value.length;
            charCounter.textContent = `${currentLength}/500`;
            charCounter.style.color = currentLength >= 480 ? "red" : "#666";
        });
    }

    // Form submission with validation
    contactForm.addEventListener("submit", function(e) {
        e.preventDefault();

        const nameField = document.getElementById("name");
        const emailField = document.getElementById("email");
        const phoneField = document.getElementById("phoneNumber");
        const messageField = document.getElementById("message");

        // Reset previous validation messages
        [nameField, emailField, phoneField, messageField].forEach(input => {
            if(input) input.setCustomValidity("");
        });

        // 1. Check for empty required fields
        if (!nameField.value.trim() || !emailField.value.trim() || !phoneField.value.trim() || !messageField.value.trim()) {
            alert("אנא מלא את כל שדות החובה");
            return;
        }

        // 2. Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(emailField.value.trim())) {
            emailField.setCustomValidity("אנא הזן כתובת אימייל תקינה");
            emailField.reportValidity();
            return;
        }

        // 3. Validate phone number (starts with 0, exactly 10 digits)
        const phoneRegex = /^0\d{9}$/;
        if (!phoneRegex.test(phoneField.value.trim())) {
            phoneField.setCustomValidity("מספר טלפון חייב להכיל 10 ספרות ולהתחיל ב-0");
            phoneField.reportValidity();
            return;
        }

        // If all checks pass, submit to server
        const formData = new FormData();
        formData.append("name", nameField.value);
        formData.append("email", emailField.value);
        formData.append("phone", phoneField.value);
        formData.append("message", messageField.value);
        
        if (fileInput && fileInput.files[0]) {
            formData.append("file", fileInput.files[0]);
        }

        fetch("/api/contact", {
            method: "POST",
            body: formData
        })
        .then(res => {
            if (!res.ok) throw new Error("Server error: " + res.status);
            return res.json();
        })
        .then(data => {
            alert("הפנייה נשלחה ונשמרה בהצלחה!");
            contactForm.reset();
            if (fileStatusContainer) fileStatusContainer.style.display = "none";
            if (charCounter) charCounter.textContent = "0/500";
        })
        .catch(err => {
            console.error("Error sending form:", err);
            alert("חלה שגיאה בשליחת הפנייה. וודא שהשרת פועל.");
        });
    });
});

// CART PAGE
document.addEventListener("DOMContentLoaded", function() {

    const cartItemsEl = document.getElementById("cartItems");
    const totalPriceEl = document.getElementById("totalPrice");

    const prices = {
        "סדנת יזמות – כיתתית": 2000,
        "סדנת חינוך פיננסי – כיתתית": 2000,
        "סדנת יזמות – שכבתית": 6000,
        "סדנת חינוך פיננסי – שכבתית": 6000,
        "תחרות חדשנות / האקתון": 10000
    };

    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let selectedItems = cart.map((_, i) => i);

    // Render cart items and total
    function renderCart() {
        cartItemsEl.innerHTML = "";
        let total = 0;

        if (cart.length === 0) {
            cartItemsEl.innerHTML = "<p class='empty-cart'>העגלה ריקה</p>";
            totalPriceEl.textContent = "₪0";
            return;
        }

        cart.forEach((item, index) => {
            const price = prices[item] || 0;
            const isChecked = selectedItems.includes(index);
            if (isChecked) total += price;

            cartItemsEl.innerHTML += `
                <div class="cart-row">
                    <input type="checkbox" ${isChecked ? "checked" : ""} onchange="toggleItem(${index})">
                    <span class="cart-item-name">${item}</span>
                    <span class="cart-price">₪${price.toLocaleString()}</span>
                    <button class="remove-btn" onclick="removeItem(${index})">✕</button>
                </div>
            `;
        });

        totalPriceEl.textContent = `₪${total.toLocaleString()}`;
    }

    // Toggle item selection
    window.toggleItem = function(index) {
        const item = cart[index];
        if (selectedItems.includes(index)) {
            selectedItems = selectedItems.filter(i => i !== index);
        } else {
            selectedItems.push(index);
        }
        renderCart();
    }

    // Remove item from cart
    window.removeItem = function(index) {
        const removedItem = cart[index];
        cart.splice(index, 1);
        selectedItems = selectedItems.filter(i => i !== removedItem);
        localStorage.setItem("cart", JSON.stringify(cart));
        renderCart();
    }

    // Contact representative with selected items
    window.contactRepresentative = function () {

        const username = localStorage.getItem("username");
        const email = localStorage.getItem("userEmail");

        if (!username || !email) {
            alert("יש להתחבר לאתר כדי לשלוח פנייה");
            window.location.href = "login.html";
            return;
        }

        if (selectedItems.length === 0) {
            alert("לא נבחרו תכניות לפנייה");
            return;
        }

        // Build cart summary with quantities
        const cartSummary = {};
        selectedItems.forEach(index => {
            const itemName = cart[index];
            if (cartSummary[itemName]) {
                cartSummary[itemName]++;
            } else {
                cartSummary[itemName] = 1;
            }
        });

        fetch("/api/inquiry", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                fullName: username,
                email: email,
                items: cartSummary
            })
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                alert("פנייתך הועברה בהצלחה! נציג יצור עימך קשר בהקדם.");
                localStorage.removeItem("cart");
                window.location.reload();
            } else {
                alert("אירעה שגיאה בשליחת הפנייה");
            }
        })
        .catch(() => {
            alert("שגיאת שרת");
        });
    };

    renderCart();

});

// REGISTER PAGE
document.getElementById("registerForm").addEventListener("submit", function (event) {
  // Prevent default submit to perform validation
  event.preventDefault();

  const fullname = document.getElementById("fullname");
  const email = document.getElementById("email");
  const phone = document.getElementById("phone");
  const password = document.getElementById("password");
  const password2 = document.getElementById("password2");

  // Reset previous custom validity messages
  [fullname, email, phone, password, password2].forEach(input => {
    input.setCustomValidity("");
  });

  // Validate full name: letters + spaces only
  const nameRegex = /^[\p{L} ]+$/u;
  if (!nameRegex.test(fullname.value.trim())) {
    fullname.setCustomValidity("שדה זה יכול להכיל רק אותיות ורווחים");
    fullname.reportValidity();
    return;
  }

  // Validate email format
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email.value.trim())) {
    email.setCustomValidity("אנא הזן כתובת אימייל תקינה (לדוגמה: name@gmail.com)");
    email.reportValidity();
    return;
  }

  // Validate phone: starts with 0 and exactly 10 digits
  const phoneRegex = /^0\d{9}$/;
  if (!phoneRegex.test(phone.value.trim())) {
    phone.setCustomValidity("מספר טלפון חייב להתחיל ב-0 ולהכיל 10 ספרות בלבד");
    phone.reportValidity();
    return;
  }

  // Check passwords match
  if (password.value !== password2.value) {
    password2.setCustomValidity("הסיסמאות אינן תואמות");
    password2.reportValidity();
    return;
  }

  // All validations passed, submit form normally
  event.target.submit();
});
