// server/index.js
const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
const sql = require("./db.js");

// Controllers
const USERS = require("./CRUD_users.js");
const CONTACT = require("./CRUD_contact.js");
const INQUIRY = require("./CRUD_inquiries.js");

const app = express();
const PORT = 3000;

// --- Middleware ---
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "../public"))); // serve static files

// --- Helper to serve HTML pages ---
const servePage = (fileName) => (req, res) => {
  res.sendFile(path.join(__dirname, "../public", fileName));
};

// --- GET Pages ---
app.get("/", servePage("index.html"));
app.get("/about", servePage("about.html"));
app.get("/products", servePage("products.html"));
app.get("/gallery", servePage("gallery.html"));
app.get("/cart", servePage("cart.html"));
app.get("/contact", servePage("contact.html"));
app.get("/login", servePage("login.html"));
app.get("/register", servePage("register.html"));

// --- Contact form ---
app.post("/api/contact", CONTACT.upload.single("file"), CONTACT.saveMessage);

// --- Inquiry (cart) form ---
app.post("/api/inquiry", INQUIRY.createInquiry);

// --- User auth ---
app.post("/register", USERS.registerUser);
app.post("/login", USERS.loginUser);

// --- Start server ---
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
