// server/CRUD_inquiries.js

const sql = require("./db.js"); // Import database connection

// Function to create a new inquiry
const createInquiry = (req, res) => {
    const { fullName, email, items } = req.body; // Extract data from request body

    // 1. Input validation from the browser
    // Check that all required fields are present and that the cart is not empty
    if (!fullName || !email || !items || typeof items !== "object" || Object.keys(items).length === 0) {
        console.log("Validation failed: Missing fields or empty cart", req.body);
        return res.status(400).json({ 
            success: false, 
            message: "מידע חסר או עגלה ריקה" // "Missing data or empty cart"
        });
    }

    console.log(`Processing inquiry for: ${email}`);

    // 2. Retrieve phone number from users table to ensure the user exists
    sql.query(
        "SELECT phone FROM users WHERE email = ?",
        [email],
        (err, results) => {
            if (err) {
                console.error("Database error during user lookup:", err);
                return res.status(500).json({ success: false, message: "שגיאת בסיס נתונים" }); // "Database error"
            }

            if (results.length === 0) {
                console.log(`User not found in DB for email: ${email}`);
                return res.status(404).json({ 
                    success: false, 
                    message: "משתמש לא נמצא במערכת. נסה להתחבר מחדש." // "User not found. Please log in again."
                });
            }

            const phone = results[0].phone; // Get the user's phone number
            const itemsJson = JSON.stringify(items); // Convert items object to JSON string

            // 3. Insert the inquiry into the "inquiries" table
            sql.query(
                "INSERT INTO inquiries (full_name, email, phone, items) VALUES (?, ?, ?, ?)",
                [fullName, email, phone, itemsJson],
                (err2, insertResult) => {
                    if (err2) {
                        console.error("SQL Error during INSERT into inquiries:", err2);
                        // If you get an error here, ensure the "items" column is of type TEXT or JSON
                        return res.status(500).json({ 
                            success: false, 
                            message: "שגיאה בשמירת הפנייה", // "Error saving inquiry"
                            errorDetail: err2.code 
                        });
                    }

                    console.log("Inquiry saved successfully! ID:", insertResult.insertId);
                    res.json({ success: true }); // Send success response
                }
            );
        }
    );
};

// Export the function for use in routes
module.exports = { createInquiry };
