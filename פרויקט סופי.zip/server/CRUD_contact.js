// CRUD_contact.js

const sql = require("./db.js"); // Import database connection
const multer = require("multer"); // Import multer for file uploads
const path = require("path"); // Import path module for handling file paths

// 1. File storage configuration
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        // Define the folder where uploaded files will be stored
        const destPath = path.join(__dirname, '..', 'public', 'uploads');
        cb(null, destPath);
    },
    filename: (req, file, cb) => {
        // Generate a unique filename to prevent overwriting
        // Use current timestamp + original file extension
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

// Initialize multer with the defined storage configuration
const upload = multer({ storage: storage });

// 2. Function to save a contact message to the database
const saveMessage = (req, res) => {
    const { name, email, phone, message } = req.body; // Extract fields from request body

    // If a file was uploaded, save its relative path
    const filePath = req.file ? `/uploads/${req.file.filename}` : null;

    // Construct the message object for insertion
    const newMessage = {
        full_name: name,
        email: email,
        phoneNumber: phone,
        message: message,
        file_path: filePath
    };

    // Insert the message into the "contact_messages" table
    sql.query("INSERT INTO contact_messages SET ?", newMessage, (err, result) => {
        if (err) {
            console.error("Database Error:", err);
            return res.status(500).json({ error: "Failed to save to database" });
        }
        res.status(200).json({ message: "Success" }); // Send success response
    });
};

// Export the functions for use in routes
module.exports = { 
    saveMessage, 
    upload 
};
