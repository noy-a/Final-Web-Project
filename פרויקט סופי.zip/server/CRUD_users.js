// server/CRUD_users.js

const sql = require("./db.js"); // Import database connection

// Function to register a new user
const registerUser = (req, res) => {
  // Check if request body is empty
  if (!req.body) return res.status(400).send("Content can not be empty!");

  const { full_name, email, phone, password, password2 } = req.body;

  // Basic server-side validations (edge cases)
  if (!full_name || String(full_name).trim().length < 2) {
    return res.status(400).send("Invalid full name");
  }

  const emailStr = String(email || "").trim();
  if (!emailStr.includes("@") || !emailStr.includes(".")) {
    return res.status(400).send("Invalid email");
  }

  const phoneStr = String(phone || "").trim();
  if (phoneStr.length < 7) {
    return res.status(400).send("Invalid phone");
  }

  if (!password || String(password).length < 4) {
    return res.status(400).send("Password too short");
  }

  if (password2 !== undefined && String(password) !== String(password2)) {
    return res.status(400).send("Passwords do not match");
  }

  // Create user object to insert into database
  const user = {
    full_name: String(full_name).trim(),
    email: emailStr,
    phone: phoneStr,
    password: String(password)
  };

  // Insert new user into "users" table
  sql.query("INSERT INTO users SET ?", user, (err) => {
    if (err) {
      if (err.code === "ER_DUP_ENTRY") {
        console.log("Email already exists.");
        return res.status(400).send("Email already exists");
      }
      console.log("Error in registering")
      return res.status(400).send("error in registering user: " + err);
    }
    // Registration successful
    // res.redirect("/login.html"); // Optionally redirect to login page
    return res.send("✅ נרשמת בהצלחה!"); // "Successfully registered!"
  });
};


// Function to login a user
const loginUser = (req, res) => {
  const { email, password } = req.body;

  // Basic validation: check if email and password exist
  if (!email || !password) {
    return res.status(400).send("Missing email or password");
  }

  // Query the database for user with matching email and password
  sql.query(
    "SELECT full_name, email FROM users WHERE email = ? AND password = ?",
    [email, password],
    (err, results) => {

      if (err) {
        return res.status(400).send("DB error"); // Database query error
      }

      // If no user found
      if (results.length === 0) {
        return res.status(400).send("אימייל או סיסמה שגויים"); // "Wrong email or password"
      }

      // User found
      const user = results[0];

      // Send a small HTML page that saves user info in localStorage and redirects to homepage
      res.send(`
        <!doctype html>
        <html lang="he" dir="rtl">
        <head>
          <meta charset="UTF-8">
          <title>מתחבר...</title>
        </head>
        <body>
          <p>התחברת בהצלחה, מעבירים אותך לדף הבית...</p> <!-- "Logged in successfully, redirecting..." -->

          <script>
            localStorage.setItem("username", ${JSON.stringify(user.full_name)});
            localStorage.setItem("userEmail", ${JSON.stringify(user.email)});
            window.location.href = "/index.html"; // Redirect to homepage
          </script>
        </body>
        </html>
      `);
    }
  );
};


// Export functions for use in routes
module.exports = { registerUser, loginUser };
