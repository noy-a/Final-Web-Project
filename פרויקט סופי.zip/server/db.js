// server/db.js
const mysql = require("mysql2");
const dbConfig = require("./db.config.js");

const connection = mysql.createConnection({
  host: dbConfig.HOST,
  user: dbConfig.USER,
  password: dbConfig.PASSWORD,
  database: dbConfig.DB,
  charset: dbConfig.charset
});


// Open the MySQL connection
connection.connect((err) => {
  if (err) {
    console.log("DB connection failed:", err);
    return;
  }
  console.log("DB connected ✅");
});

// Correct export
module.exports = connection;
