// server/db.config.js
module.exports = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "Noy506109889",
  DB: "web_project_db",
  charset: "utf8mb4"
};
